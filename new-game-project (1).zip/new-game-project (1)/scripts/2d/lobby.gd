extends Control

# UI References
@onready var select_server_btn = $"Lobbies/Find Servers"
@onready var select_server_list = $"Lobbies/List of the server"
@onready var server_list_vbox = $"Lobbies/List of the server/ScrollContainer/ServerListVBox"
@onready var create_host_btn = $Lobbies/Create_Host
@onready var connect_join_btn = $Lobbies/Connect_Join

# Communication Nodes
@onready var firebase_request = $"Control/Control/$FirebaseRequest"

# REST API Endpoint Configurations
# NOTICE: We point explicitly to /lobbies.json now to keep out other metrics!
const FIREBASE_URL = "https://game-server-4a36c-default-rtdb.firebaseio.com/lobbies.json"

# State Tracking Variables
var selected_server_id: String = ""
var selected_server_ip: String = ""
var active_buttons: Dictionary = {}

func _ready() -> void:
	# Enforce proper setup on start
	select_server_list.visible = false 
	create_host_btn.visible = false
	connect_join_btn.visible = false
	
	# Connect Button Events via code
	create_host_btn.pressed.connect(_on_create_host_pressed)
	connect_join_btn.pressed.connect(_on_connect_join_pressed)
	
	# Wire up HTTP handling
	firebase_request.request_completed.connect(_on_firebase_request_completed)

func _on_find_servers_pressed() -> void:
	var toggle_state = not select_server_list.visible
	
	select_server_list.visible = toggle_state
	create_host_btn.visible = toggle_state
	connect_join_btn.visible = toggle_state
	
	if toggle_state:
		fetch_servers()

# -----------------------------------------------------------------
# Network Operations & Data Fetching
# -----------------------------------------------------------------

func fetch_servers() -> void:
	# Clear out UI list nodes instantly
	for child in server_list_vbox.get_children():
		child.queue_free()
	active_buttons.clear()
	selected_server_id = ""
	selected_server_ip = ""
	
	var headers = ["Content-Type: application/json"]
	firebase_request.request(FIREBASE_URL, headers, HTTPClient.METHOD_GET)

func _on_create_host_pressed() -> void:
	# Template payload structures (Replace with interactive inputs as needed)
	var lobby_payload = {
		"server_name": "Giga Room #" + str(randi() % 1000),
		"host_name": "Player_" + str(randi() % 100),
		"current_players": 1,
		"max_players": 8,
		"ip_address": "127.0.0.1"
	}
	
	var json_payload = JSON.stringify(lobby_payload)
	var headers = ["Content-Type: application/json"]
	
	# POST puts a newly random-keyed sub-item under /lobbies
	firebase_request.request(FIREBASE_URL, headers, HTTPClient.METHOD_POST, json_payload)
	
	# Dynamic structural layout refresh loop execution
	await get_tree().create_timer(0.8).timeout
	fetch_servers()

func _on_connect_join_pressed() -> void:
	if selected_server_id == "" or selected_server_ip == "":
		print("[Lobby System] Alert: Select a target room connection first.")
		return
		
	print("[Lobby System] Instantiating low-level connection protocol to target host...")
	print("Connecting to ID: ", selected_server_id, " at IP Address: ", selected_server_ip)
	
	# Integrate your low-level game client instantiation connections here:
	# var peer = ENetMultiplayerPeer.new()
	# peer.create_client(selected_server_ip, 7777)
	# multiplayer.multiplayer_peer = peer

# -----------------------------------------------------------------
# Response Handling Engines
# -----------------------------------------------------------------

func _on_firebase_request_completed(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if response_code != 200:
		print("[Network Failure] Database returned error response code: ", response_code)
		return
		
	var parsing_stream = body.get_string_from_utf8()
	if parsing_stream == "null" or parsing_stream.strip_edges() == "":
		print("[Lobby System] Active registry folder reports empty.")
		return
		
	var clean_dictionary = JSON.parse_string(parsing_stream)
	
	if typeof(clean_dictionary) == TYPE_DICTIONARY:
		for unique_id in clean_dictionary.keys():
			var room_data = clean_dictionary[unique_id]
			
			# Data verification layer ensures strings/integers don't break logic
			if typeof(room_data) == TYPE_DICTIONARY:
				build_server_entry_ui(unique_id, room_data)
	else:
		print("[Structural Error] Root directory returned unexpected non-dictionary format.")

func build_server_entry_ui(server_id: String, attributes: Dictionary) -> void:
	var list_button = Button.new()
	
	# Fetch properties cleanly with fallback safety structures
	var name_string = attributes.get("server_name", "Standard Server")
	var host_string = attributes.get("host_name", "Host")
	var current_count = str(attributes.get("current_players", 1))
	var max_count = str(attributes.get("max_players", 4))
	var network_ip = attributes.get("ip_address", "127.0.0.1")
	
	list_button.text = " %s | Host: %s | Slots: (%s/%s)" % [name_string, host_string, current_count, max_count]
	list_button.custom_minimum_size = Vector2(0, 45)
# To this:
	list_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	
	# Connect choice actions using inline functional lambdas
	list_button.pressed.connect(func():
		selected_server_id = server_id
		selected_server_ip = network_ip
		highlight_selected_room(server_id)
		print("[User Select] Confirmed Room Target: ", server_id, " | Network Route: ", network_ip)
	)
	
	server_list_vbox.add_child(list_button)
	active_buttons[server_id] = list_button

func highlight_selected_room(target_id: String) -> void:
	# Clear out old visual button modulations and highlight the selected one
	for id in active_buttons.keys():
		if active_buttons[id] is Button:
			active_buttons[id].modulate = Color(1, 1, 1, 1) 
			
	if active_buttons.has(target_id):
		active_buttons[target_id].modulate = Color(0.3, 0.8, 1, 1) # Bright Cyan Selection
