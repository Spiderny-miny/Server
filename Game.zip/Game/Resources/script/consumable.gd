extends ActionData
class_name ConsumableAction

@export modifier_name: String
@export modifier_value: int

func _init() -> void:
    action_type = ActionType.CONSUMABLE