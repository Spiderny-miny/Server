extends Resources
class_name ActionData

enum ActionType { INVALID, CONSUMABLE, EQUIPPABLE, INSPECTABLE} 
var action_type: Actiontype